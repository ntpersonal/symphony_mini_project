<?php

namespace App\Entity;

use App\Repository\UtilsateurRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: UtilsateurRepository::class)]
class Utilsateur
{

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToMany(targetEntity: Groupe::class, mappedBy: 'listeUtilisateur')]
    private Collection $Grp;

    public function __construct()
    {
        $this->Grp = new ArrayCollection();
    }
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection<int, Groupe>
     */
    public function getGrp(): Collection
    {
        return $this->Grp;
    }

    public function addGrp(Groupe $grp): self
    {
        if (!$this->Grp->contains($grp)) {
            $this->Grp->add($grp);
            $grp->addListeUtilisateur($this);
        }

        return $this;
    }

    public function removeGrp(Groupe $grp): self
    {
        if ($this->Grp->removeElement($grp)) {
            $grp->removeListeUtilisateur($this);
        }

        return $this;
    }
}
