<?php

namespace App\Entity;

use App\Repository\GroupeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: GroupeRepository::class)]
class Groupe
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToMany(targetEntity: Utilsateur::class, inversedBy: 'Grp')]
    private Collection $listeUtilisateur;

    public function __construct()
    {
        $this->listeUtilisateur = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection<int, Utilsateur>
     */
    public function getListeUtilisateur(): Collection
    {
        return $this->listeUtilisateur;
    }

    public function addListeUtilisateur(Utilsateur $listeUtilisateur): self
    {
        if (!$this->listeUtilisateur->contains($listeUtilisateur)) {
            $this->listeUtilisateur->add($listeUtilisateur);
        }

        return $this;
    }

    public function removeListeUtilisateur(Utilsateur $listeUtilisateur): self
    {
        $this->listeUtilisateur->removeElement($listeUtilisateur);

        return $this;
    }
}
