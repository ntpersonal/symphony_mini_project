<?php

namespace App\Entity;

use App\Repository\EtudiantRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: EtudiantRepository::class)]
class Etudiant
{
    /**
      * @ORM\ManyToOne(targetEntity= "institut")
      * @ORM\JoinColumn(name="institut_id", referencedColumnName="id")
      */
      Private $instit ;
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 35)]
    private ?string $mone = null;

    // #[ORM\Column(length: 35)]
    // private ?string $instit = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getMone(): ?string
    {
        return $this->mone;
    }

    public function setMone(string $mone): self
    {
        $this->mone = $mone;

        return $this;
    }

     /**
     * Set instit
     *
     * @param test\gestscolBundle\Entity\institut $instit
     *
     * @return etudiant
     */
    public function setInstit($instit)
    {
        $this->instit = $instit;

        return $this;
    }

    /**
     * Get nome
     *
     * @return \gestscolBundle\Entity\institut
     */
    public function getInstit()
    {
        return $this->instit;
    }

}
