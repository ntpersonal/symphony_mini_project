<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use App\Factory\EtudiantFactory;
use App\Factory\GroupeFactory;
use App\Factory\InstitutFactory;
use App\Factory\UtilsateurFactory;
use App\Factory\FilliereFactory;
class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        // $product = new Product();
        // $manager->persist($product);
        EtudiantFactory ::createMany(10);
        UtilsateurFactory ::createMany(10);
        GroupeFactory ::createMany(10);
        InstitutFactory ::createMany(10);
        $manager->flush();
    }
}
